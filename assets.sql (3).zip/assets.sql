-- phpMyAdmin SQL Dump
-- version 4.1.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 06, 2014 at 10:05 PM
-- Server version: 5.5.37-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `assets`
--

-- --------------------------------------------------------

--
-- Table structure for table `assets`
--

CREATE TABLE IF NOT EXISTS `assets` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `location` varchar(500) NOT NULL,
  `custodian` varchar(500) NOT NULL,
  `status` enum('inactive','active','under_maintenance') NOT NULL DEFAULT 'inactive',
  `istemara_expiry` date DEFAULT NULL,
  `insurance_expiry` date DEFAULT NULL,
  `preventive_maintenance` date DEFAULT NULL,
  `tuv_sticker` date DEFAULT NULL,
  `client_sticker` date DEFAULT NULL,
  `mot_license_expiry` date DEFAULT NULL,
  `accident_history` text,
  `violation_history` text,
  `vendor` text NOT NULL,
  `asset_category` text NOT NULL,
  `department` text NOT NULL,
  `vehicle_number` text NOT NULL,
  `serial_number` text NOT NULL,
  `purchase_price` text NOT NULL,
  `current_value` text NOT NULL,
  `total_maintenance` text NOT NULL,
  `total_depreciation` text NOT NULL,
  `date_acquired` date DEFAULT NULL,
  `date_sold` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=49 ;

--
-- Dumping data for table `assets`
--

INSERT INTO `assets` (`id`, `name`, `description`, `location`, `custodian`, `status`, `istemara_expiry`, `insurance_expiry`, `preventive_maintenance`, `tuv_sticker`, `client_sticker`, `mot_license_expiry`, `accident_history`, `violation_history`, `vendor`, `asset_category`, `department`, `vehicle_number`, `serial_number`, `purchase_price`, `current_value`, `total_maintenance`, `total_depreciation`, `date_acquired`, `date_sold`) VALUES
(2, 'liftsqaa', 'Main lift this wayaa', 'rPaa', 'Mohammed Talha', 'active', '2014-10-07', '2014-10-08', '2014-10-09', '2014-10-10', '2014-10-11', '2014-10-12', 'aaaaaaaa', 'vvvvaaaaaa', '', 'fhf', 'zdfwe', '', '', '', '', '', '', '0000-00-00', '0000-00-00'),
(14, 'Computer', 'IBMs', 'Main server room', 'Salmans', 'active', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', NULL, NULL),
(15, 'Moto e', 'sdf \r\n \r\n', 'pettai', 'talhaa', 'under_maintenance', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', NULL, NULL),
(16, 'Sony', 'ericson prodct \r\n', 'pettai', 'talha', 'active', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', NULL, NULL),
(17, 'Xpefia', 'tip \r\n', 'al', 'Ali', 'active', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', NULL, NULL),
(18, 'CPU', 'intel \r\nsdf', 'rP', 'talhaa', 'inactive', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', NULL, NULL),
(19, 'nokia 108', 'The brand new nokia 108 for us \r\n', 'table', 'Salman', 'active', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', NULL, NULL),
(20, 'test asset', 'sdfsrfsf', 'sfd', 'Sdf', 'active', '2014-10-08', NULL, NULL, NULL, NULL, NULL, 'Thi is tesxt', 'sfdsfsf', '', '', '', '', '', '', '', '', '', NULL, NULL),
(23, 'name', 'desc', 'loc', 'cust', 'active', NULL, NULL, NULL, NULL, NULL, NULL, 'accsa', 'viosa', '', '', '', '', '', '', '', '', '', NULL, NULL),
(24, 'test asset 1', 'asset desc', 'ass loc', 'custodia', 'active', '2014-10-01', '2014-10-02', NULL, NULL, NULL, NULL, 'accid his', 'violhis', '', '', '', '', '', '', '', '', '', NULL, NULL),
(26, 'test aset 2', 'asset desc', 'ass loc', 'cus', 'active', '2014-10-01', '2014-10-22', NULL, NULL, NULL, NULL, 'acc his', 'vio his', '', '', '', '', '', '', '', '', '', NULL, NULL),
(27, 'test aset 3', 'ASDF', 'ass loc', 'cus', 'active', '2014-10-01', '0000-00-00', NULL, NULL, NULL, NULL, 'ACC', 'VIO', '', '', '', '', '', '', '', '', '', NULL, NULL),
(28, 'Asset Name', 'deswc', 'loc', 'cus', 'under_maintenance', '2014-10-01', '2014-10-02', '2014-10-03', '2014-10-04', '2014-10-05', '2014-10-06', 'acc', 'vio', '', '', '', '', '', '', '', '', '', NULL, NULL),
(29, 'Asset Name', 'deswc', 'loc', 'cus', 'under_maintenance', '2014-10-01', '2014-10-02', '2014-10-03', '2014-10-04', '2014-10-05', '2014-10-06', 'acc', 'vio', '', '', '', '', '', '', '', '', '', NULL, NULL),
(30, 'Asset Name', 'deswc', 'loc', 'cus', 'under_maintenance', '2014-10-01', '2014-10-02', '2014-10-03', '2014-10-04', '2014-10-05', '2014-10-06', 'acc', 'vio', '', '', '', '', '', '', '', '', '', NULL, NULL),
(31, 'aaaaa ba', 'asdf', 'ass loc', 'talhatha', 'under_maintenance', '2014-10-20', '2014-10-21', '2014-10-22', '2014-10-23', '2014-10-24', '2014-10-25', 'asfa', 'asdfbv', '', '', '', '', '', '', '', '', '', NULL, NULL),
(36, 'NEW TEST', 'Ass desc', 'ass loc', 'cus', 'active', '2014-10-01', '2014-10-02', '2014-10-02', '2014-10-03', '2014-10-04', '2014-10-05', 'acc  ', 'vio', '1', '2', '3', 'veh num', '', 'pur', 'cur', 'tot mina', 'tot dep', '2014-10-06', '2014-10-07'),
(48, 'Moto E', 'My Own motorolla', 'table', 'Mohammed Talha', 'active', '2014-10-01', '2014-10-02', '2014-10-03', '2014-10-04', '2014-10-05', '2014-10-06', 'NIL', 'nil', 'Mazdas', 'Vehicle', 'Human resources', '9788755', 'XT895', '7000', '6999', 'tot mina', 'tot dep', '2014-10-07', '2014-10-08');

-- --------------------------------------------------------

--
-- Table structure for table `assets_category`
--

CREATE TABLE IF NOT EXISTS `assets_category` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `asset_category_name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `assets_category`
--

INSERT INTO `assets_category` (`id`, `asset_category_name`) VALUES
(1, 'Vehicle'),
(5, 'ds gvfdsga'),
(7, 'dfgbfg'),
(8, 'bfg'),
(9, 'fgnfgn'),
(10, 'fhf'),
(11, 'fghfgn'),
(12, 'ffghfg'),
(13, 'fgnfnf'),
(14, 'nfnfgn'),
(16, 'Baombs');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE IF NOT EXISTS `department` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `department_name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `department_name`) VALUES
(1, 'Human resources'),
(7, 'zdfwe'),
(8, 'fw');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE IF NOT EXISTS `employee` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `employee_name` varchar(200) NOT NULL,
  `employee_email` varchar(50) NOT NULL,
  `employee_department` varchar(200) NOT NULL,
  `employee_phone` varchar(20) NOT NULL,
  `employee_status` enum('inactive','active') NOT NULL DEFAULT 'inactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `employee_name`, `employee_email`, `employee_department`, `employee_phone`, `employee_status`) VALUES
(1, 'Mohammed Alisaa', 'sdsdf@gmcil.com', 'humansaa', '9876465ss', 'active'),
(2, 'Mohammed Talha', 'talha@object90.com', 'programmer', '9788179303', 'active'),
(3, 'Ramesh kumar', 'rameshkumar86@gmacil.com', '', '234234', 'active'),
(4, 'Prasanth B', '', '', '', ''),
(5, 'Mariappan C', '', '', '', ''),
(6, 'Vally anand', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `google_users`
--

CREATE TABLE IF NOT EXISTS `google_users` (
  `id` int(5) NOT NULL,
  `google_id` decimal(21,0) NOT NULL,
  `google_name` varchar(60) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `google_email` varchar(60) NOT NULL,
  `users_user_role_id` int(3) NOT NULL,
  `google_link` varchar(60) NOT NULL,
  `google_picture_link` varchar(60) NOT NULL,
  PRIMARY KEY (`google_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `google_users`
--

INSERT INTO `google_users` (`id`, `google_id`, `google_name`, `username`, `password`, `google_email`, `users_user_role_id`, `google_link`, `google_picture_link`) VALUES
(1, 100428232109775983047, 'Mohammed Talha', '', '', 'talhaqqq@gmail.com', 1, 'https://plus.google.com/100428232109775983047', 'https://lh3.googleusercontent.com/-XdUIqdMkCWA/AAAAAAAAAAI/A'),
(2, 100678434091494690900, 'Mohammed Talha', 'talha@object90.com', 'pass', 'talha@object90.com', 0, 'https://plus.google.com/100678434091494690900', 'https://lh3.googleusercontent.com/-XdUIqdMkCWA/AAAAAAAAAAI/A'),
(3, 106219740134865583912, 'ramesh balakrishnan', '', '', 'rameshkumar86@gmail.com', 0, 'https://plus.google.com/106219740134865583912', 'https://lh5.googleusercontent.com/-nCqLiYHWuJM/AAAAAAAAAAI/A'),
(4, 118161579513011654715, 'Roney Philip', 'roneyp20@gmail.com', 'philip', 'roneyp20@gmail.com', 0, 'https://plus.google.com/118161579513011654715', 'https://lh3.googleusercontent.com/-XdUIqdMkCWA/AAAAAAAAAAI/A');

-- --------------------------------------------------------

--
-- Table structure for table `screens`
--

CREATE TABLE IF NOT EXISTS `screens` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `screen_name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `screens`
--

INSERT INTO `screens` (`id`, `screen_name`) VALUES
(1, 'assets_screen'),
(2, 'alerts_screen'),
(3, 'employees_screen'),
(4, 'configure_screen'),
(5, 'role_table_screen');

-- --------------------------------------------------------

--
-- Table structure for table `users_screens`
--

CREATE TABLE IF NOT EXISTS `users_screens` (
  `userrole_screen_id` int(5) DEFAULT NULL,
  `user_role_id` int(5) NOT NULL,
  `screen_id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

CREATE TABLE IF NOT EXISTS `user_roles` (
  `user_role_id` int(5) NOT NULL AUTO_INCREMENT,
  `user_role_name` varchar(100) NOT NULL,
  `user_role_screens` varchar(500) NOT NULL,
  PRIMARY KEY (`user_role_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `user_roles`
--

INSERT INTO `user_roles` (`user_role_id`, `user_role_name`, `user_role_screens`) VALUES
(1, 'Admin', 'a:2:{i:0;s:1:"1";i:1;s:1:"2";}'),
(2, 'Data Entry Operator', ''),
(3, 'Asset Co-ordinator', ''),
(4, 'Approver', '');

-- --------------------------------------------------------

--
-- Table structure for table `vendor`
--

CREATE TABLE IF NOT EXISTS `vendor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vendor_name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `vendor`
--

INSERT INTO `vendor` (`id`, `vendor_name`) VALUES
(1, 'Mazdas'),
(8, 'sdfdfgdf'),
(9, 'dbdfsg'),
(10, 'dfgdb'),
(11, 'sdfgb sf'),
(12, 'fgbnf'),
(13, 'fgn'),
(14, 'sdbsdfg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
